@echo off
setlocal
title Data Science XL - Einrichtung
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Einrichten.ps1"
if errorlevel 1 (
    echo.
    echo Die Einrichtung hat einen Fehler gemeldet. Bitte die Meldung oben beachten.
)
echo.
pause
