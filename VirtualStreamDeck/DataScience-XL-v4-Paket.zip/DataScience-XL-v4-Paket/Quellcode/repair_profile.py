"""Fill a real Stream Deck export while retaining its complete page hierarchy."""
from pathlib import Path
from io import BytesIO
from copy import deepcopy
from PIL import Image
import json, shutil, struct, uuid, zipfile, zlib

ROOT = Path('/workspace/scratch/3f357a78faf7')
OUT = ROOT / 'output'
SOURCE = ROOT / 'upload' / 'DataScience.streamDeckProfile'
PREVIOUS = OUT / 'DataScience-XL.streamDeckProfile'
DESTINATION = OUT / 'DataScience-XL-v2.streamDeckProfile'
PACK = OUT / 'DataScience-XL-v2-Paket'

with zipfile.ZipFile(SOURCE) as z:
    original = [(deepcopy(info), z.read(info.filename)) for info in z.infolist()]
with zipfile.ZipFile(PREVIOUS) as z:
    home_name = next(n for n in z.namelist() if n.endswith('/manifest.json') and n.count('/') == 4)
    home = json.loads(z.read(home_name))
    assets = {s['Image']: z.read(str(Path(home_name).parent / s['Image']))
              for a in home['Controllers'][0]['Actions'].values() for s in a['States']}

original_profile = next(i.filename for i, _ in original if i.filename.endswith('manifest.json') and i.filename.count('/') == 2)
old_base = str(Path(original_profile).parent)
new_base = f'Profiles/{str(uuid.uuid4()).upper()}.sdProfile'
umbrella = json.loads(next(data for i, data in original if i.filename == original_profile))
assert len(umbrella['Pages']['Pages']) == 1
default_id = umbrella['Pages']['Default'].upper()
home_id = umbrella['Pages']['Pages'][0].upper()
assert default_id != home_id
default_file = f'{old_base}/Profiles/{default_id}/manifest.json'
default_bytes = next(data for i, data in original if i.filename == default_file)
assert json.loads(default_bytes)['Controllers'][0]['Actions'] is None
umbrella['Name'] = 'Data Science XL v2'
original_pages = deepcopy(umbrella['Pages'])
home_path = f'{old_base}/Profiles/{home_id}/manifest.json'
home_template = json.loads(next(data for i, data in original if i.filename == home_path))
home_template['Controllers'][0]['Actions'] = home['Controllers'][0]['Actions']

# The portable key images contain their labels; preserve Elgato's font defaults.
for action in home_template['Controllers'][0]['Actions'].values():
    for state in action['States']:
        state.update(FontFamily='', FontStyle='', OutlineThickness=2)

entries = []
file_template = next(i for i, _ in original if i.filename == home_path)
for info, data in original:
    if info.filename == original_profile:
        data = json.dumps(umbrella, ensure_ascii=False, separators=(',', ':')).encode()
    elif info.filename == home_path:
        data = json.dumps(home_template, ensure_ascii=False, separators=(',', ':')).encode()
    # Package metadata, the empty default page, and all original folder pages
    # are left unchanged. The user-facing page remains in Pages.Pages.
    info.filename = info.filename.replace(old_base, new_base, 1)
    entries.append((info, data))
for relative, data in assets.items():
    info = deepcopy(file_template)
    info.filename = f'{new_base}/Profiles/{home_id}/{relative}'
    entries.append((info, data))

def write_windows_export(path, entries):
    """Match the original export's ZIP headers, NTFS attributes and descriptors."""
    central = []
    with path.open('wb') as f:
        for info, data in entries:
            name = info.filename.encode('utf-8')
            extra = info.extra
            directory = info.filename.endswith('/')
            method = 0 if directory else 8
            flags = 0x800 if directory else 0x808
            crc = zlib.crc32(data) & 0xffffffff
            if method == 8:
                compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
                compressed = compressor.compress(data) + compressor.flush()
            else:
                compressed = data
            year, month, day, hour, minute, second = info.date_time
            dos_time = (hour << 11) | (minute << 5) | (second // 2)
            dos_date = ((year - 1980) << 9) | (month << 5) | day
            offset = f.tell()
            f.write(struct.pack('<4s5H3I2H', b'PK\x03\x04', 20, flags, method,
                                dos_time, dos_date, 0 if not directory else crc,
                                0 if not directory else len(compressed), len(data),
                                len(name), len(extra)))
            f.write(name); f.write(extra); f.write(compressed)
            if not directory:
                f.write(struct.pack('<4s3I', b'PK\x07\x08', crc, len(compressed), len(data)))
            central.append((info, name, extra, flags, method, crc, len(compressed),
                            len(data), dos_time, dos_date, offset))
        start = f.tell()
        for info, name, extra, flags, method, crc, packed, unpacked, dt, dd, offset in central:
            f.write(struct.pack('<4s6H3I5H2I', b'PK\x01\x02',
                                (info.create_system << 8) | info.create_version,
                                20, flags, method, dt, dd, crc, packed, unpacked,
                                len(name), len(extra), len(info.comment), 0,
                                info.internal_attr, info.external_attr, offset))
            f.write(name); f.write(extra); f.write(info.comment)
        length = f.tell() - start
        f.write(struct.pack('<4s4H2IH', b'PK\x05\x06', 0, 0, len(central),
                            len(central), length, start, 0))

write_windows_export(DESTINATION, entries)

with zipfile.ZipFile(DESTINATION) as z:
    assert z.testzip() is None
    assert z.namelist()[0] == 'package.json'
    assert z.read('package.json') == original[0][1]
    m = json.loads(z.read(f'{new_base}/manifest.json'))
    assert m['Pages'] == original_pages and m['Pages']['Pages']
    assert z.read(f'{new_base}/Profiles/{default_id}/manifest.json') == default_bytes
    for page_id in [m['Pages']['Default']] + m['Pages']['Pages']:
        assert f'{new_base}/Profiles/{page_id.upper()}/manifest.json' in z.namelist()
    main = json.loads(z.read(f'{new_base}/Profiles/{home_id}/manifest.json'))
    actions = main['Controllers'][0]['Actions']
    assert set(actions) == {f'{x},{y}' for y in range(4) for x in range(8)}
    assert len({a['ActionID'] for a in actions.values()}) == 32
    for a in actions.values():
        path = f'{new_base}/Profiles/{home_id}/' + a['States'][0]['Image']
        image = Image.open(BytesIO(z.read(path)))
        assert image.size == (144, 144)
    assert all(i.create_system == 10 and i.create_version == 45 for i in z.infolist())
    assert all(i.flag_bits == (0x800 if i.is_dir() else 0x808) for i in z.infolist())

if PACK.exists():
    shutil.rmtree(PACK)
shutil.copytree(OUT / 'DataScience-XL-Paket', PACK)
(PACK / 'DataScience-XL.streamDeckProfile').unlink()
shutil.copyfile(DESTINATION, PACK / DESTINATION.name)
script = PACK / 'Einrichten.ps1'
text = script.read_text()
text = text.replace('DataScience-XL.streamDeckProfile', DESTINATION.name)
text = text.replace('Start-Process -FilePath $profileSource',
                    "$importUri = 'streamdeck://app/openfile/' + [Uri]::EscapeDataString([IO.Path]::GetFullPath($profileSource))\n            Start-Process -FilePath $importUri")
text = text.replace('"Data Science XL"', '"Data Science XL v2"')
script.write_bytes(text.replace('\r\n', '\n').replace('\n', '\r\n').encode())
readme = PACK / 'Anleitung.txt'
text = readme.read_text(encoding='utf-8-sig')
text = text.replace('Version 1 /', 'Version 2 /').replace('DataScience-XL.streamDeckProfile', DESTINATION.name).replace('"Data Science XL"', '"Data Science XL v2"')
text = '''IMPORTKORREKTUR V2
Dieses Profil behält die vollständige Seitenstruktur deines Originalexports:
eine leere technische Standardseite und eine echte Seite mit 32 Tasten.
Auch die Windows-Archivmetadaten entsprechen dem Originalexport.

Zum ersten Test die einzelne DataScience-XL-v2.streamDeckProfile herunterladen.
In der laufenden Stream-Deck-App über Einstellungen > Profile > Importieren
öffnen. So hängt der Test nicht von der Windows-Dateizuordnung ab.

WINDOWSBENUTZER
Einrichten.cmd muss im Windowskonto ausgeführt werden, in dem du VS Code
und Stream Deck verwendest. Es ermittelt APPDATA jeweils für dieses Konto.
Das Profil selbst enthält keinen Pfad zum vorherigen Windowsbenutzer.
Der Startordner bleibt C:\\AI; prüfen, ob dieses Konto darauf zugreifen kann.

''' + text
text = text.replace('Auch ein Doppelklick auf die .streamDeckProfile-Datei ist moeglich,', 'Ein Doppelklick auf die .streamDeckProfile-Datei ist ebenfalls moeglich,')
readme.write_text(text, encoding='utf-8-sig')
shutil.copyfile(Path(__file__), PACK / 'Quellcode' / 'repair_profile.py')
ZIP = OUT / 'DataScience-XL-v2-Paket.zip'
with zipfile.ZipFile(ZIP, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in sorted(PACK.rglob('*')):
        if path.is_file(): z.write(path, path.relative_to(OUT))
with zipfile.ZipFile(ZIP) as z: assert z.testzip() is None
print(json.dumps({'corrected_profile': str(DESTINATION), 'bundle': str(ZIP),
                  'default_page': 'original empty page, byte-identical',
                  'listed_home_pages': len(original_pages['Pages']), 'home_keys': 32,
                  'zip_metadata': 'original NTFS style, all CRCs valid',
                  'windows_username_paths': 0, 'real_windows_import': 'pending on user PC'}, indent=2))
