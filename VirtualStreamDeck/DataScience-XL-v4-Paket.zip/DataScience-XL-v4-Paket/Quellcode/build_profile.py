from __future__ import annotations
import json, math, shutil, uuid, zipfile
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/workspace/scratch/3f357a78faf7')
OUT = ROOT / 'output'
PACK = OUT / 'DataScience-XL-Paket'
ICONS = PACK / 'Icons'
ICONS.mkdir(parents=True, exist_ok=True)
FAMILY = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
BOLD = '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
MONO = '/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf'
COLORS = ['#68b8ff', '#ffc067', '#bea3ff', '#67d9c1']
CATEGORY = ['WORKSPACE', 'GIT', 'NOTEBOOK', 'LERNEN']
WHITE = '#f4f7ff'
SIZE = 144
SCALE = 4

class Canvas:
    def __init__(self, color):
        self.im = Image.new('RGB', (SIZE*SCALE, SIZE*SCALE), '#0d1523')
        self.d = ImageDraw.Draw(self.im)
        self.color = color
    def pts(self, v):
        return tuple(round(x*SCALE) for x in v)
    def line(self, points, fill=None, width=4):
        self.d.line([self.pts(p) for p in points], fill=fill or WHITE, width=round(width*SCALE), joint='curve')
        rad=width*SCALE/2
        for p in (points[0], points[-1]):
            x,y=self.pts(p)
            self.d.ellipse((int(x-rad),int(y-rad),int(x+rad),int(y+rad)), fill=fill or WHITE)
    def rect(self, b, fill=None, outline=None, radius=0, width=3):
        if radius:
            self.d.rounded_rectangle(self.pts(b),radius=round(radius*SCALE),fill=fill,outline=outline,width=round(width*SCALE))
        else:
            self.d.rectangle(self.pts(b),fill=fill,outline=outline,width=round(width*SCALE))
    def oval(self,b,fill=None,outline=None,width=3):
        self.d.ellipse(self.pts(b),fill=fill,outline=outline,width=round(width*SCALE))
    def poly(self,points,fill):
        self.d.polygon([self.pts(p) for p in points],fill=fill)
    def arc(self,b,start,end,fill=None,width=4):
        self.d.arc(self.pts(b),start,end,fill=fill or WHITE,width=round(width*SCALE))
    def text(self,pos,txt,size=16,fill=None,font=BOLD,anchor='mm'):
        f=ImageFont.truetype(font,round(size*SCALE))
        self.d.text(self.pts(pos),txt,font=f,fill=fill or WHITE,anchor=anchor)
    def folder(self, accent=True):
        self.poly([(38,47),(60,47),(68,55),(106,55),(106,88),(38,88)],'#152d42')
        self.line([(38,88),(38,47),(60,47),(68,55),(106,55),(106,88),(38,88)],fill=self.color if accent else WHITE,width=3.6)
    def arrow(self, down):
        if down:
            self.line([(72,42),(72,74)],fill=self.color,width=5)
            self.line([(60,63),(72,76),(84,63)],fill=self.color,width=5)
        else:
            self.line([(72,79),(72,47)],fill=self.color,width=5)
            self.line([(60,58),(72,45),(84,58)],fill=self.color,width=5)
        self.line([(48,83),(48,92),(96,92),(96,83)],width=3.7)

def draw_symbol(c, k):
    a=c.color
    if k=='vscode':
        c.poly([(39,53),(50,47),(70,62),(93,38),(107,44),(107,89),(93,95),(70,74),(50,87),(39,81),(57,67)],a)
        c.poly([(92,49),(75,67),(92,84)],'#0d1523')
    elif k in ['terminal','command']:
        c.rect((36,41,108,91),outline=a,radius=8,width=4)
        c.line([(47,54),(60,66),(47,78)],width=4)
        c.line([(69,78),(89,78)],fill=a,width=4)
        if k=='command':
            c.oval((98,30,116,48),fill=a)
            c.text((107,39),'P',size=10,fill='#0d1523')
    elif k=='jupyter':
        c.arc((45,38,99,91),10,170,fill=a,width=6)
        c.arc((45,38,99,91),190,350,fill=a,width=6)
        c.oval((97,31,106,40),fill=WHITE)
        c.oval((38,82,46,90),fill=WHITE)
        c.text((72,65),'J',size=29)
    elif k=='explorer':
        c.folder()
        c.line([(50,70),(70,70)],width=4)
        c.line([(50,80),(89,80)],width=4)
    elif k=='course':
        c.folder()
        c.poly([(67,63),(83,63),(88,69),(83,75),(67,75)],a)
        c.line([(68,80),(87,80)],width=3)
    elif k=='github':
        c.oval((43,42,101,89),fill=WHITE)
        c.poly([(43,60),(44,34),(64,47)],WHITE)
        c.poly([(82,46),(101,34),(101,61)],WHITE)
        c.oval((53,63,91,81),fill='#0d1523')
        c.rect((64,82,81,100),fill=WHITE,radius=4)
        c.line([(65,92),(52,94),(42,88),(37,80)],width=5)
    elif k=='chatgpt':
        # A clear conversational symbol rather than a recreated wordmark.
        c.rect((37,41,105,83),outline=a,radius=14,width=4)
        c.line([(52,83),(45,96),(70,83)],fill=a,width=4)
        for x in [54,71,88]:c.oval((x-3,59,x+3,65),fill=WHITE)
        c.oval((98,32,111,45),fill=a)
    elif k=='claude':
        for i in range(12):
            t=2*math.pi*i/12
            c.line([(72+13*math.cos(t),65+13*math.sin(t)),(72+30*math.cos(t),65+30*math.sin(t))],fill=a,width=4)
        c.oval((63,56,81,74),fill=WHITE)
    elif k=='status':
        c.rect((45,39,99,96),outline=WHITE,radius=7,width=4)
        c.rect((58,34,86,46),fill=a,radius=4)
        for y in [61,79]:
            c.line([(54,y),(58,y+4),(65,y-5)],fill=a,width=3)
            c.line([(73,y),(89,y)],width=3)
    elif k in ['pull','push']:
        c.arrow(k=='pull')
    elif k=='add':
        c.folder()
        c.line([(73,63),(73,81)],fill=a,width=4)
        c.line([(64,72),(82,72)],fill=a,width=4)
    elif k=='commit':
        c.line([(34,66),(110,66)],fill=a,width=4)
        c.oval((47,41,97,91),fill='#0d1523',outline=a,width=4)
        c.line([(60,66),(69,75),(85,57)],width=5)
    elif k in ['branch','repo']:
        if k=='repo':c.folder()
        dx=0;dy=0;scale=1
        pts=[(58,41),(58,88),(92,42)]
        if k=='repo':pts=[(61,65),(61,84),(88,64)]
        top,bot,right=pts
        c.line([top,bot],fill=WHITE,width=4)
        c.line([right,(right[0],bot[1]-13),(top[0],bot[1]-6)],fill=WHITE,width=4)
        r=6 if k=='branch' else 4
        for x,y in pts:c.oval((x-r,y-r,x+r,y+r),fill=a)
    elif k=='log':
        c.line([(49,43),(49,92)],fill=a,width=3)
        for y,w in [(45,39),(67,49),(89,33)]:
            c.oval((43,y-6,55,y+6),fill=a)
            c.line([(66,y),(66+w,y)],width=4)
    elif k in ['run','runall']:
        if k=='run':c.poly([(55,38),(100,66),(55,94)],a)
        else:
            c.poly([(36,43),(70,66),(36,89)],a)
            c.poly([(76,43),(110,66),(76,89)],WHITE)
    elif k=='code':
        c.line([(54,45),(38,63),(54,81)],fill=a,width=5)
        c.line([(90,45),(106,63),(90,81)],fill=a,width=5)
        c.line([(78,40),(65,87)],width=4)
        c.oval((100,76,122,98),fill=a)
        c.line([(106,87),(116,87)],fill='#0d1523',width=2)
        c.line([(111,82),(111,92)],fill='#0d1523',width=2)
    elif k=='markdown':
        c.rect((32,44,112,87),outline=a,radius=5,width=4)
        c.line([(45,73),(45,57),(54,66),(63,57),(63,73)],width=3.4)
        c.line([(88,55),(88,75)],width=3.8)
        c.line([(79,67),(88,76),(97,67)],width=3.8)
    elif k=='restart':
        c.arc((44,38,100,94),37,334,fill=a,width=6)
        c.poly([(107,54),(87,51),(103,37)],a)
        c.text((72,68),'K',size=22)
    elif k=='save':
        c.poly([(43,37),(92,37),(105,50),(105,96),(39,96),(39,37)],a)
        c.rect((51,39,88,59),fill='#0d1523',radius=2)
        c.rect((50,70,94,96),fill=WHITE,radius=3)
        c.rect((74,43,82,54),fill=a)
    elif k=='variables':
        c.rect((38,40,107,94),outline=a,radius=5,width=3)
        c.line([(38,57),(107,57)],fill=a,width=3)
        c.line([(65,57),(65,94)],fill=a,width=3)
        c.text((51,74),'x',size=20)
        c.text((86,74),'42',size=15)
    elif k=='pandas':
        for x,y,h in [(44,46,40),(68,35,29),(68,72,25),(92,47,40)]:
            c.rect((x,y,x+12,y+h),fill=a,radius=2)
        c.rect((44,33,56,39),fill=WHITE,radius=1)
        c.rect((92,94,104,100),fill=WHITE,radius=1)
    elif k=='numpy':
        c.poly([(72,35),(104,52),(72,71),(40,52)],a)
        c.poly([(40,55),(69,73),(69,99),(40,81)],'#419dd0')
        c.poly([(75,73),(104,55),(104,81),(75,99)],WHITE)
        c.line([(53,48),(85,67)],fill='#0d1523',width=2)
        c.line([(59,43),(92,62)],fill='#0d1523',width=2)
        c.line([(55,59),(86,43)],fill='#0d1523',width=2)
        c.line([(63,65),(94,48)],fill='#0d1523',width=2)
    elif k=='matplotlib':
        c.line([(40,39),(40,91),(108,91)],width=4)
        c.line([(49,79),(65,61),(82,70),(101,45)],fill=a,width=4)
        for x,y in [(49,79),(65,61),(82,70),(101,45)]:c.oval((x-3,y-3,x+3,y+3),fill=a)
    elif k=='sklearn':
        c.line([(39,41),(39,91),(109,91)],width=3)
        for x,y in [(50,76),(58,62),(70,75),(57,84)]:c.oval((x-4,y-4,x+4,y+4),fill=a)
        for x,y in [(83,52),(91,61),(99,42),(79,44)]:c.oval((x-4,y-4,x+4,y+4),fill='#ffbb71')
        c.line([(67,92),(83,37)],fill=WHITE,width=2)
    elif k=='cheatsheet':
        c.poly([(36,43),(64,43),(72,49),(80,43),(108,43),(108,91),(80,91),(72,97),(64,91),(36,91)],'#183345')
        c.line([(72,49),(72,95)],fill=a,width=3)
        c.line([(36,43),(64,43),(72,49),(80,43),(108,43),(108,91),(80,91),(72,97),(64,91),(36,91),(36,43)],fill=a,width=3)
        for y in [57,68,79]:
            c.line([(44,y),(62,y)],width=2.5)
            c.line([(82,y),(100,y)],width=2.5)
    elif k=='discord':
        c.poly([(49,44),(61,39),(64,44),(80,44),(83,39),(96,44),(108,80),(96,90),(90,82),(54,82),(48,90),(36,80)],a)
        c.oval((53,58,65,71),fill='#0d1523')
        c.oval((80,58,92,71),fill='#0d1523')
        c.arc((52,60,94,78),10,170,fill='#0d1523',width=2)
    elif k=='zoom':
        c.rect((34,45,86,86),fill=a,radius=9)
        c.poly([(91,56),(111,44),(111,87),(91,75)],WHITE)
    elif k=='notes':
        c.rect((40,39,98,95),outline=a,radius=5,width=3)
        for y in [52,65,78]:c.line([(52,y),(82,y)],width=3)
        c.poly([(90,78),(105,47),(114,51),(99,82),(89,90)],WHITE)

def make_icon(index, label, symbol):
    row=index//8
    c=Canvas(COLORS[row])
    c.rect((3,3,141,141),outline='#213249',radius=13,width=1)
    c.rect((16,10,128,14),fill=COLORS[row],radius=2)
    c.text((72,24),CATEGORY[row],size=7.6,fill=COLORS[row])
    draw_symbol(c,symbol)
    lines=label.split('\n')
    fsize=14.5
    if max(len(v) for v in lines)>9:fsize=12.2
    if len(lines)==1:c.text((72,117),lines[0],size=fsize)
    else:
        c.text((72,111),lines[0],size=fsize)
        c.text((72,128),lines[1],size=fsize)
    image=c.im.resize((144,144),Image.Resampling.LANCZOS)
    name=f'{index+1:02d}-{symbol}.png'
    image.save(ICONS/name,optimize=True)
    return image,name

def uid():return str(uuid.uuid4())
blank={'KeyCmd':False,'KeyCtrl':False,'KeyModifiers':0,'KeyOption':False,'KeyShift':False,'NativeCode':146,'QTKeyCode':33554431,'VKeyCode':-1}
def hotkey(key, ctrl=False,alt=False,shift=False):
    if key.startswith('F'):
        n=int(key[1:]);vk=111+n;qt=0x01000030+n-1
    else:vk=qt=ord(key.upper())
    h={'KeyCmd':False,'KeyCtrl':ctrl,'KeyModifiers':(2 if ctrl else 0)+(4 if alt else 0)+(1 if shift else 0),'KeyOption':alt,'KeyShift':shift,'NativeCode':vk,'QTKeyCode':qt,'VKeyCode':vk}
    return {'Coalesce':True,'Hotkeys':[h]+[dict(blank) for _ in range(3)]}
def fn(n,shift=False):return hotkey(f'F{n}',ctrl=True,alt=True,shift=shift)
def site(url):return ('website',{'openInBrowser':True,'path':url})
def op(path):return ('open',{'path':path})
def hk(settings):return ('hotkey',settings)

buttons=[
 ('VS CODE','vscode',site('vscode://file/C:/AI'),'VS Code mit dem Ordner C:\\AI oeffnen.'),
 ('TERMINAL','terminal',hk(fn(1,True)),'Integriertes Terminal in VS Code fokussieren.'),
 ('JUPYTER','jupyter',hk(fn(2,True)),'Neues Jupyter-Notebook in VS Code anlegen.'),
 ('EXPLORER','explorer',hk(hotkey('E',ctrl=True,shift=True)),'Datei-Explorer in VS Code anzeigen.'),
 ('KURS\nORDNER','course',op('C:\\AI'),'Windows-Explorer im Ordner C:\\AI oeffnen.'),
 ('GITHUB','github',site('https://github.com/karstenuhlighh'),'Dein GitHub-Profil im Browser oeffnen.'),
 ('CHATGPT','chatgpt',site('https://chatgpt.com/'),'ChatGPT im Browser oeffnen.'),
 ('CLAUDE','claude',hk(fn(3,True)),'claude im integrierten Terminal vorbereiten; Enter selbst druecken.'),
 ('STATUS','status',hk(fn(1)),'git status vorbereiten.'),
 ('PULL','pull',hk(fn(2)),'git pull --ff-only vorbereiten.'),
 ('ADD','add',hk(fn(3)),'git add . vorbereiten.'),
 ('COMMIT','commit',hk(fn(4)),'git commit -m " vorbereiten; Nachricht und Schlusszeichen selbst ergaenzen.'),
 ('PUSH','push',hk(fn(5)),'git push vorbereiten.'),
 ('BRANCH','branch',hk(fn(6)),'git branch --show-current vorbereiten.'),
 ('LOG','log',hk(fn(7)),'git log --oneline --graph --decorate -15 vorbereiten.'),
 ('REPO','repo',hk(hotkey('G',ctrl=True,shift=True)),'Quellcodeverwaltung des aktuellen VS-Code-Projekts oeffnen.'),
 ('RUN CELL','run',hk(fn(4,True)),'Aktuelle Notebook-Zelle ausfuehren und zur naechsten wechseln.'),
 ('RUN ALL','runall',hk(fn(5,True)),'Alle Zellen des aktuellen Notebooks ausfuehren.'),
 ('+ CODE','code',hk(fn(6,True)),'Neue Code-Zelle unterhalb der ausgewaehlten Zelle einfuegen.'),
 ('MARKDOWN','markdown',hk(fn(7,True)),'Ausgewaehlte Notebook-Zelle zu Markdown umwandeln.'),
 ('RESTART\nKERNEL','restart',hk(fn(8,True)),'Jupyter-Kernel neu starten (normaler VS-Code-Dialog bleibt erhalten).'),
 ('SAVE','save',hk(hotkey('S',ctrl=True)),'Aktive Datei / aktives Notebook speichern.'),
 ('COMMANDS','command',hk(hotkey('P',ctrl=True,shift=True)),'VS-Code-Befehlspalette oeffnen.'),
 ('VARIABLES','variables',hk(fn(9,True)),'Jupyter-Variablenansicht oeffnen.'),
 ('PANDAS','pandas',site('https://pandas.pydata.org/docs/'),'Offizielle pandas-Dokumentation.'),
 ('NUMPY','numpy',site('https://numpy.org/doc/'),'Offizielle NumPy-Dokumentation.'),
 ('MATPLOTLIB','matplotlib',site('https://matplotlib.org/stable/'),'Offizielle Matplotlib-Dokumentation.'),
 ('SKLEARN','sklearn',site('https://scikit-learn.org/stable/'),'Offizielle scikit-learn-Dokumentation.'),
 ('CHEAT\nSHEET','cheatsheet',site('https://docs.python.org/3/tutorial/datastructures.html'),'Python-Datenstrukturen und Comprehensions im offiziellen Tutorial.'),
 ('DISCORD','discord',site('https://discord.com/channels/@me'),'Discord im Browser oeffnen.'),
 ('ZOOM','zoom',site('https://zoom.us/signin#/login'),'Zoom-Anmeldung im Browser oeffnen; keine Besprechung starten.'),
 ('NOTIZEN','notes',op('notepad'),'Windows-Editor oeffnen.'),
]

bindings=[]
def bind(n,command,shift=False,when=None,args=None):
    b={'key':f'ctrl+alt+{"shift+" if shift else ""}f{n}','command':command}
    if when:b['when']=when
    if args is not None:b['args']=args
    bindings.append(b)

bind(1,'workbench.action.terminal.focus',True)
bind(2,'ipynb.newUntitledIpynb',True)
def terminal_binding(n,text,shift=False):
    bind(n,'runCommands',shift,args={'commands':['workbench.action.terminal.focus',{'command':'workbench.action.terminal.sendSequence','args':{'text':text}}]})
terminal_binding(3,'claude',True)
commands=['git status','git pull --ff-only','git add .','git commit -m "','git push','git branch --show-current','git log --oneline --graph --decorate -15']
for n,cmd in enumerate(commands,1):terminal_binding(n,cmd)
notebook_when="notebookEditorFocused && notebookType == 'jupyter-notebook'"
for n,command in [(4,'notebook.cell.executeAndSelectBelow'),(5,'notebook.execute'),(6,'notebook.cell.insertCodeCellBelow'),(7,'notebook.cell.changeToMarkdown'),(8,'jupyter.restartkernel'),(9,'jupyter.openVariableView')]:
    bind(n,command,True,notebook_when)
(PACK/'VSCode-Keybindings.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=4)+'\n',encoding='utf-8')

with zipfile.ZipFile(ROOT/'upload/DataScience.streamDeckProfile') as source:
    package=json.loads(source.read('package.json'))
    manifest=json.loads(source.read('Profiles/BEE3C9B1-75BE-4BE1-8EA5-F833AADEBAFE.sdProfile/manifest.json'))
profile_id=uid().upper()
page_id=uid().upper()
base=f'Profiles/{profile_id}.sdProfile'
page=f'{base}/Profiles/{page_id}'
manifest['Name']='Data Science XL'
manifest['Pages']={'Current':'00000000-0000-0000-0000-000000000000','Default':page_id.lower(),'Pages':[]}
package['RequiredPlugins']=['com.elgato.streamdeck.system.hotkey','com.elgato.streamdeck.system.open','com.elgato.streamdeck.system.website']
actions={};images=[]
for i,(label,symbol,(kind,settings),desc) in enumerate(buttons):
    im,name=make_icon(i,label,symbol)
    images.append(im)
    uuid_action=f'com.elgato.streamdeck.system.{kind}'
    action={'ActionID':uid(),'LinkedTitle':True,'Name':{'hotkey':'Hotkey','website':'Website','open':'Open'}[kind],
            'Resources':None,'Settings':settings,'State':0,
            'States':[{'FontFamily':'Arial','FontSize':14,'FontStyle':'Bold','FontUnderline':False,'Image':f'Images/{name}','OutlineThickness':0,'ShowTitle':False,'Title':label,'TitleAlignment':'bottom','TitleColor':'#ffffff'}],
            'UUID':uuid_action}
    actions[f'{i%8},{i//8}']=action
page_manifest={'Controllers':[{'Actions':actions,'Type':'Keypad'}],'Icon':'','Name':'Data Science Home'}
profile_path=PACK/'DataScience-XL.streamDeckProfile'
with zipfile.ZipFile(profile_path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for directory in ['Profiles/',base+'/',base+'/Images/',base+'/Profiles/',page+'/',page+'/Images/']:
        z.writestr(directory,b'')
    z.writestr('package.json',json.dumps(package,ensure_ascii=False,separators=(',',':')))
    z.writestr(base+'/manifest.json',json.dumps(manifest,ensure_ascii=False,separators=(',',':')))
    z.writestr(page+'/manifest.json',json.dumps(page_manifest,ensure_ascii=False,separators=(',',':')))
    for p in sorted(ICONS.glob('*.png')):z.write(p,page+'/Images/'+p.name)

shutil.copyfile(profile_path,OUT/'DataScience-XL.streamDeckProfile')

# Show precisely the images embedded in the profile, in physical XL order.
preview=Image.new('RGB',(1920,1080),'#08111e')
d=ImageDraw.Draw(preview)
def txt(x,y,s,text,color=WHITE,bold=False):
    d.text((x,y),text,font=ImageFont.truetype(BOLD if bold else FAMILY,s),fill=color)
txt(64,36,15,'KARSTEN / DATA SCIENCE',COLORS[0],True)
txt(60,64,49,'Deine Data-Science-Konsole',bold=True)
txt(64,128,21,'STREAM DECK XL   /   32 TASTEN   /   WINDOWS + VS CODE',color='#a1b1c5')
startx=280;starty=206;stepx=197;stepy=197;render_size=174
subtitles=['Tools & Workspace','Befehle vorbereiten','Jupyter in VS Code','Docs & Kurswerkzeuge']
for row in range(4):
    y=starty+stepy*row
    d.rounded_rectangle((59,y+8,65,y+166),radius=3,fill=COLORS[row])
    txt(87,y+48,21,CATEGORY[row],COLORS[row],True)
    txt(87,y+80,15,subtitles[row],color='#a1b1c5')
    for col in range(8):
        im=images[row*8+col].resize((render_size,render_size),Image.Resampling.LANCZOS)
        preview.paste(im,(startx+stepx*col,y))
txt(64,1028,17,'GIT: Befehl pruefen, dann Enter.   |   Notebook-Tasten: VS Code aktiv, .ipynb geoeffnet.',color='#9cadc2')
preview.save(OUT/'DataScience-XL-Vorschau.png',optimize=True)
shutil.copyfile(OUT/'DataScience-XL-Vorschau.png',PACK/'DataScience-XL-Vorschau.png')

readme='''DATA SCIENCE XL - Karstens Startprofil
Version 1 / 30.09.2026 / Windows / Stream Deck XL / VS Code

SCHNELLSTART
1. Das gesamte ZIP entpacken, z. B. in C:\\AI\\StreamDeck-DataScience.
2. Im entpackten Ordner Einrichten.cmd doppelklicken.
   Das Skript ergaenzt 16 Tastenkombinationen in VS Code und erstellt
   vorher eine Sicherung einer bereits vorhandenen keybindings.json.
   Anschliessend oeffnet es die mitgelieferte .streamDeckProfile-Datei.
3. Den Import in Stream Deck abschliessen und "Data Science XL" waehlen.
4. VS Code in den Vordergrund holen. TERMINAL und JUPYTER testen.

Falls die Importdatei nicht automatisch geoeffnet wird:
In Stream Deck Einstellungen > Profile > Importieren verwenden und
DataScience-XL.streamDeckProfile aus dem Paket auswaehlen.
Auch ein Doppelklick auf die .streamDeckProfile-Datei ist moeglich,
sofern Windows sie der Stream-Deck-App zugeordnet hat.

WAS IST KONFIGURIERT?
32 native Elgato-Aktionen mit 32 eingebetteten PNG-Symbolen.
Keine zusaetzlichen Stream-Deck-Plugins noetig.
Das Profil basiert auf deinem Windows-Export aus Stream Deck 7.5.1.
Es bekommt eine neue Profil-ID und einen eigenen Namen.

BLAU - WORKSPACE
VS CODE    VS Code ueber vscode://file/C:/AI oeffnen.
TERMINAL   Integriertes Terminal in VS Code fokussieren.
JUPYTER    Neues .ipynb-Notebook in VS Code erstellen.
EXPLORER   Datei-Explorer in VS Code anzeigen.
KURSORDNER Windows-Explorer im bekannten Basisordner C:\\AI oeffnen.
GITHUB     github.com/karstenuhlighh im Browser.
CHATGPT    chatgpt.com im Browser.
CLAUDE     Terminal fokussieren und claude vorbereiten.

ORANGE - GIT
STATUS     git status
PULL       git pull --ff-only
ADD        git add .
COMMIT     git commit -m "
PUSH       git push
BRANCH     git branch --show-current
LOG        git log --oneline --graph --decorate -15
REPO       Quellcodeverwaltung des aktuellen VS-Code-Projekts.

Alle sieben Git-Befehle werden nur vorbereitet, ohne Enter.
Pruefe zuerst, ob das aktive Terminal im richtigen Repository steht
und an einer leeren Eingabezeile wartet. Erst dann die Taste druecken.
Danach Befehl pruefen und selbst Enter druecken.
COMMIT: Nachricht schreiben, mit einem weiteren " schliessen, Enter.
Beispiel: git commit -m "Add first pandas exercise"
BRANCH zeigt den aktuellen Branch; es erstellt oder wechselt keinen Branch.
PULL verwendet --ff-only und bricht ab, wenn ein Merge erforderlich waere.
ADD beruecksichtigt alle nicht ignorierten Aenderungen im aktuellen Ordner.

VIOLETT - NOTEBOOK
RUN CELL   Ausgewaehlte Zelle ausfuehren und naechste Zelle auswaehlen.
RUN ALL    Alle Zellen ausfuehren.
+ CODE     Eine neue Code-Zelle unterhalb einfuegen.
MARKDOWN   Ausgewaehlte Zelle zu Markdown umwandeln.
RESTART    Kernel neu starten; VS-Codes Standardbestaetigung bleibt erhalten.
SAVE       Aktive Datei speichern (Ctrl+S).
COMMANDS   Befehlspalette oeffnen (Ctrl+Shift+P).
VARIABLES  Jupyter-Variablenansicht anzeigen.

TUERKIS - LERNEN
PANDAS / NUMPY / MATPLOTLIB / SKLEARN: offizielle Dokumentation.
CHEAT SHEET: Python-Tutorial zu Datenstrukturen und Comprehensions.
DISCORD / ZOOM: jeweilige Website im Browser.
NOTIZEN: Windows-Editor.

VORAUSSETZUNGEN
Die VS-Code-Tasten wirken auf das aktive Fenster: zuerst VS Code aktivieren.
Die Notebook-Tasten brauchen ein geoeffnetes .ipynb-Notebook sowie die
Python- und Jupyter-Erweiterungen von Microsoft und einen passenden Kernel.
Die sechs Notebook-Aktionen sind auf den Notebook-Kontext beschraenkt.
CLAUDE nutzt deine bestehende Claude-Code-Installation im aktiven Terminal.
Das Profil installiert keine Software, startet kein Meeting und fuehrt
keinen Git-Befehl automatisch aus.

ORDNER ANPASSEN
Dein genauer Kursordner war im Export nicht enthalten.
Deshalb stehen VS CODE und KURSORDNER initial auf C:\\AI.
In Stream Deck den Button KURSORDNER anklicken und das Ziel aendern.
Beim Button VS CODE die URL auf vscode://file/C:/AI/DEIN-KURSORDNER aendern.
Ein Repo im aktuellen VS-Code-Fenster kannst du auch wie gewohnt oeffnen.

WAS DIE EINRICHTUNG AENDERT
Standardziel: %APPDATA%\\Code\\User\\keybindings.json
Das Skript ergaenzt einen markierten Block mit ctrl+alt+F1 bis F7
und ctrl+alt+shift+F1 bis F9. Vorhandene Eintraege und Kommentare bleiben
erhalten. Diese seltenen Kombinationen sollten fuer das Deck frei sein.
Bei erneutem Ausfuehren wird der Block nicht noch einmal hinzugefuegt.
Eine vorhandene Datei wird vor der Aenderung bytegenau als .bak gesichert.
Die PowerShell-Ausfuehrungseinstellung gilt nur fuer diesen gestarteten
Prozess; die dauerhaften Windows-Einstellungen werden nicht geaendert.
Einrichten.ps1 ist Klartext und kann vorab geoeffnet werden.

BENANNTES VS-CODE-PROFIL / INSIDERS / PORTABLE
Die automatische Einrichtung zielt auf das normale Standardprofil von
VS Code. Falls du ein anderes Profil nutzt: dessen keybindings.json ueber
"Preferences: Open Keyboard Shortcuts (JSON)" oeffnen und den Dateipfad
ermitteln. Dann Einrichten.ps1 mit -KeybindingsPath "voller Pfad" ausfuehren.
Alternativ die Eintraege aus VSCode-Keybindings.json in das bestehende
Array uebernehmen. Die bestehende Datei nicht komplett ersetzen.

RUECKGAENGIG MACHEN
In VS Code nur den Block zwischen KARSTEN_DATASCIENCE_DECK_V1 und
ENDE_KARSTEN_DATASCIENCE_DECK_V1 entfernen; bei einem vorher vorhandenen
Eintrag auch das davor eingefuegte Trennkomma entfernen.
Oder die unmittelbar vor der Einrichtung erstellte .bak zurueckkopieren,
solange du seither keine weiteren Tastenkombinationen geaendert hast.
Das Profil kann in Stream Deck separat entfernt werden.

PRUEFUNG UND GRENZEN
Geprueft: ZIP-Struktur, Manifeste, alle 32 Positionen, eingebettete Symbole,
eindeutige IDs und die Zuordnung zwischen Hotkeys und VS-Code-Bindings.
Der reale Import und die Windows-Einrichtung muessen auf deinem PC getestet
werden; diese Umgebung hat weder deine Stream-Deck-App noch Windows.

TECHNISCHE QUELLEN
https://docs.elgato.com/streamdeck/sdk/guides/profiles/
https://docs.elgato.com/stream-deck/profiles/packaging/
https://code.visualstudio.com/docs/configure/keybindings
https://code.visualstudio.com/docs/configure/command-line
https://code.visualstudio.com/api/references/commands
https://github.com/microsoft/vscode-jupyter/blob/main/package.json
https://github.com/microsoft/vscode/blob/main/extensions/ipynb/package.json
https://github.com/microsoft/vscode-docs/blob/main/build/keybindings/doc.keybindings.win.json
'''
(PACK/'Anleitung.txt').write_text(readme,encoding='utf-8-sig')
inventory=[]
for i,(label,symbol,(kind,settings),desc) in enumerate(buttons):
    inventory.append({'position':f'{i%8},{i//8}','row':i//8+1,'column':i%8+1,'label':label,'symbol':f'Icons/{i+1:02d}-{symbol}.png','action':kind,'settings':settings,'description':desc})
(PACK/'Tastenbelegung.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

print(json.dumps({'profile':str(profile_path),'preview':str(OUT/'DataScience-XL-Vorschau.png'),'buttons':len(buttons),'bindings':len(bindings),'profile_id':profile_id,'page_id':page_id},indent=2))
