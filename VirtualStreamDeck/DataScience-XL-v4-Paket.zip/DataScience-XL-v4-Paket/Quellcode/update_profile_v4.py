"""Update the user's current Stream Deck export; keep all unrelated actions."""
from pathlib import Path
from copy import deepcopy
from io import BytesIO
import ast, json, uuid, zipfile, struct, zlib, shutil
from PIL import Image, ImageDraw, ImageFont

ROOT = Path('/workspace/scratch/3f357a78faf7')
SOURCE = ROOT / 'upload/01-Data-Science-XL-v3.streamDeckProfile'
OUT = ROOT / 'output'
PACK = OUT / 'DataScience-XL-v4-Paket'
PACK.mkdir(exist_ok=True)
DEST = OUT / 'DataScience-XL-v4.streamDeckProfile'

# Reuse only the established icon and ZIP helpers, without executing their builds.
tree = ast.parse((ROOT / 'work/build_profile.py').read_text())
prefix = []
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'buttons' for t in node.targets):
        break
    prefix.append(node)
icons = {}
exec(compile(ast.Module(body=prefix, type_ignores=[]), 'icon_helpers', 'exec'), icons)
icons['ICONS'] = PACK / 'Icons'
icons['ICONS'].mkdir(exist_ok=True)
icons['CATEGORY'][1] = 'GIT / VS CODE'
fn, hotkey = icons['fn'], icons['hotkey']
tree = ast.parse((ROOT / 'work/repair_profile.py').read_text())
writer = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'write_windows_export')
exec(compile(ast.Module(body=[writer], type_ignores=[]), 'zip_helper', 'exec'))

with zipfile.ZipFile(SOURCE) as z:
    original = [(deepcopy(i), z.read(i.filename)) for i in z.infolist()]
data_map = {i.filename: data for i, data in original}
root_manifest = next(n for n in data_map if n.endswith('/manifest.json') and n.count('/') == 2)
old_base = str(Path(root_manifest).parent)
new_base = f'Profiles/{str(uuid.uuid4()).upper()}.sdProfile'
umbrella = json.loads(data_map[root_manifest])
assert len(umbrella['Pages']['Pages']) == 2
home_id, terminal_id = [p.upper() for p in umbrella['Pages']['Pages']]
home_path = f'{old_base}/Profiles/{home_id}/manifest.json'
terminal_path = f'{old_base}/Profiles/{terminal_id}/manifest.json'
home = json.loads(data_map[home_path])
terminal = json.loads(data_map[terminal_path])
old_home = deepcopy(home)
old_terminal = deepcopy(terminal)
ha = home['Controllers'][0]['Actions']
ta = terminal['Controllers'][0]['Actions']
umbrella['Name'] = 'Data Science XL v4'
home['Name'] = 'VS Code'
terminal['Name'] = 'Git Terminal'
assets = {}
for col in range(8):
    action = deepcopy(ha[f'{col},1'])
    if col < 7:
        action['Settings'] = fn(col + 13)
    assert f'{col},0' not in ta
    ta[f'{col},0'] = action
    for state in action['States']:
        if state.get('Image'):
            assets[f'{old_base}/Profiles/{terminal_id}/{state["Image"]}'] = data_map[f'{old_base}/Profiles/{home_id}/{state["Image"]}']

gui = [
    ('ÄNDERUNGEN', 'status', None, 'workbench.view.scm'),
    ('STAGE / ADD', 'add', 1, 'git.stageAll'),
    ('COMMIT', 'commit', 2, 'git.commitStaged'),
    ('FETCH', 'pull', 3, 'git.fetch'),
    ('PULL', 'pull', 4, 'git.pull'),
    ('PUSH', 'push', 5, 'git.push'),
    ('BRANCH', 'branch', 6, 'git.checkout'),
    ('HISTORIE', 'log', 7, 'workbench.scm.history.focus'),
]
for col, (label, symbol, key, command) in enumerate(gui):
    im, name = icons['make_icon'](8 + col, label, symbol)
    name = f'gui-{col+1:02d}.png'
    buf = BytesIO(); im.save(buf, format='PNG', optimize=True)
    relative = f'Images/{name}'
    action = deepcopy(old_home['Controllers'][0]['Actions']['0,1'])
    action['ActionID'] = str(uuid.uuid4())
    action['Settings'] = fn(key) if key else hotkey('G', ctrl=True, shift=True)
    action['States'][0]['Image'] = relative
    action['States'][0]['Title'] = label
    ha[f'{col},1'] = action
    assets[f'{old_base}/Profiles/{home_id}/{relative}'] = buf.getvalue()

# The native paging action requires one key on the full main page.
notes = deepcopy(ha['7,3'])
assert '0,1' not in ta
ta['0,1'] = notes
for state in notes['States']:
    if state.get('Image'):
        assets[f'{old_base}/Profiles/{terminal_id}/{state["Image"]}'] = data_map[f'{old_base}/Profiles/{home_id}/{state["Image"]}']
next_page = deepcopy(ta['0,3'])
next_page.update(ActionID=str(uuid.uuid4()), Name='Next Page', UUID='com.elgato.streamdeck.page.next')
ha['7,3'] = next_page

replacements = {root_manifest: umbrella, home_path: home, terminal_path: terminal}
entries = []
for info, data in original:
    if info.filename in replacements:
        data = json.dumps(replacements[info.filename], ensure_ascii=False, separators=(',', ':')).encode()
    info.filename = info.filename.replace(old_base, new_base, 1)
    entries.append((info, data))
template = next(i for i, _ in original if i.filename.endswith(f'{home_id}/manifest.json'))
existing_names = {i.filename for i, _ in entries}
for path, data in assets.items():
    info = deepcopy(template)
    info.filename = path.replace(old_base, new_base, 1)
    assert info.filename not in existing_names
    existing_names.add(info.filename)
    entries.append((info, data))
write_windows_export(DEST, entries)
shutil.copyfile(DEST, PACK / DEST.name)

previous_bindings = json.loads((OUT / 'DataScience-XL-v2-Paket/VSCode-Keybindings.json').read_text())
bindings = []
for binding in previous_bindings:
    binding = deepcopy(binding)
    if binding['key'].startswith('ctrl+alt+f'):
        binding['key'] = 'ctrl+alt+f' + str(int(binding['key'].rsplit('f', 1)[1]) + 12)
    bindings.append(binding)
for label, symbol, key, command in gui:
    if key:
        bindings.append({'key':f'ctrl+alt+f{key}', 'command':command, 'when':'gitOpenRepositoryCount > 0'})
assert len(bindings) == 23 and len({b['key'] for b in bindings}) == 23
(PACK / 'VSCode-Keybindings.json').write_text(json.dumps(bindings, ensure_ascii=False, indent=4) + '\n')
shutil.copyfile(OUT / 'DataScience-XL-v2-Paket/Einrichten.cmd', PACK / 'Einrichten.cmd')

script = (OUT / 'DataScience-XL-v2-Paket/Einrichten.ps1').read_text()
start = script.index("    $marker = '// KARSTEN_DATASCIENCE_DECK_V1'")
end = script.index('    if (-not $SkipProfileImport)', start)
script = script[:start] + r'''    $marker = '// KARSTEN_DATASCIENCE_DECK_V4'
    $text = "[`r`n]`r`n"
    $existed = Test-Path -LiteralPath $KeybindingsPath -PathType Leaf
    if ($existed) { $text = [IO.File]::ReadAllText($KeybindingsPath) }
    $null = Get-ArrayInsertionPoint -Text $text
    $fragment = [IO.File]::ReadAllText($bindingSource).Trim()
    $null = ConvertFrom-Json -InputObject $fragment
    if (-not $fragment.StartsWith('[') -or -not $fragment.EndsWith(']')) { throw 'Das mitgelieferte Tastenformat ist ungueltig.' }
    $fragment = $fragment.Substring(1, $fragment.Length - 2).Trim()
    $block = "    $marker`r`n$fragment`r`n    // ENDE_KARSTEN_DATASCIENCE_DECK_V4"
    $pattern = '(?ms)^[ \t]*// KARSTEN_DATASCIENCE_DECK_V(1|4)\r?\n.*?^[ \t]*// ENDE_KARSTEN_DATASCIENCE_DECK_V\1[^\r\n]*'
    $matches = [regex]::Matches($text, $pattern)
    if ($matches.Count -gt 1) { throw 'Mehrere Data-Science-Bloecke gefunden. Es wurde nichts geaendert.' }
    if ($matches.Count -eq 1) {
        $match = $matches[0]
        $newText = $text.Substring(0, $match.Index) + $block + $text.Substring($match.Index + $match.Length)
    } else {
        if ($text.Contains('KARSTEN_DATASCIENCE_DECK_')) { throw 'Unvollstaendiger Data-Science-Block. Es wurde nichts geaendert.' }
        $point = Get-ArrayInsertionPoint -Text $text
        $separator = ''
        if ($point.NeedsComma) { $separator = ',' }
        $newText = $text.Insert($point.Index, "`r`n$separator`r`n$block`r`n")
    }
    $null = Get-ArrayInsertionPoint -Text $newText
    if ($newText -eq $text) {
        Write-Host 'Die Data-Science-Tasten sind bereits aktuell.' -ForegroundColor Green
    } else {
        if ($existed) {
            $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
            $backupPath = "$KeybindingsPath.before-datascience-$stamp.bak"
            Copy-Item -LiteralPath $KeybindingsPath -Destination $backupPath
            Write-Host "Sicherung: $backupPath"
        }
        $encoding = New-Object System.Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($KeybindingsPath, $newText, $encoding)
        Write-Host '23 Data-Science-Tastenkombinationen eingerichtet / aktualisiert.' -ForegroundColor Green
        Write-Host "Ziel: $KeybindingsPath"
    }

''' + script[end:]
script = script.replace('DataScience-XL-v2.streamDeckProfile', DEST.name).replace('Data Science XL v2', 'Data Science XL v4')
script = script.replace("Git und CLAUDE fuegen nur Text ein. Enter drueckst du selbst.", "Seite 1: Git direkt in VS Code. Seite 2: Terminaltext, Enter selbst druecken.")
(PACK / 'Einrichten.ps1').write_bytes(script.replace('\r\n', '\n').replace('\n', '\r\n').encode('utf-8-sig'))

readme = '''DATA SCIENCE XL v4 – auf Basis deines aktuellen Exports

EINRICHTEN
1. Das gesamte ZIP in einen Ordner entpacken.
2. Im Windows-Konto DataScience Einrichten.cmd starten. Auch bei bereits
   eingerichteter Version erforderlich: Die Git-Tastenkombinationen ändern sich.
3. Den Import bestätigen und „Data Science XL v4“ in Stream Deck auswählen.
   Falls kein Importdialog erscheint: Einstellungen > Profile > Importieren
   und DataScience-XL-v4.streamDeckProfile auswählen.
4. Für Git VS Code mit deinem Repository öffnen und im Vordergrund lassen.

DEINE ANPASSUNGEN
Die vorhandenen App-Starts (ChatGPT, Claude, Discord), dein Kursordner,
dein Zoom-Link, die Notebook-Tasten und übrigen Links sind übernommen.
Dein bisheriges Profil bleibt als eigene Version erhalten.
Die leere Programm-Taste auf Seite 2 bleibt erhalten.
„Notizen“ steht jetzt auf Seite 2, damit unten rechts auf Seite 1 der
Seitenwechsel Platz hat. Unten links auf Seite 2 geht es zurück.

SEITE 1 – GIT IN VS CODE (zweite Reihe, von links)
ÄNDERUNGEN: Quellcodeverwaltung anzeigen (Strg+Umschalt+G).
STAGE / ADD: Alle Änderungen im gewählten Repository stagen.
COMMIT: Bereits gestagte Änderungen committen. Nachricht vorher im
   Commit-Feld eingeben; fehlende Eingaben werden von VS Code abgefragt.
FETCH: Remote-Informationen abrufen, ohne Änderungen zu integrieren.
PULL: Änderungen abrufen und gemäß deinen VS-Code-/Git-Einstellungen integrieren.
PUSH: Lokale Commits veröffentlichen.
BRANCH: Branch-Auswahl öffnen; dort kannst du auch einen Branch anlegen.
HISTORIE: Quellcodeverwaltungsgraph / Git-Historie öffnen.
Diese Tasten führen die entsprechenden VS-Code-Aktionen direkt aus.
Bei mehreren Repositories kann VS Code eine Auswahl verlangen.
Einzelne Dateien kannst du in ÄNDERUNGEN manuell stagen.

SEITE 2 – BISHERIGE TERMINAL-GIT-TASTEN (erste Reihe)
STATUS | PULL | ADD | COMMIT | PUSH | BRANCH | LOG | REPO
Die ersten sieben bereiten genau die bisherigen Befehle vor:
git status
git pull --ff-only
git add .
git commit -m "
git push
git branch --show-current
git log --oneline --graph --decorate -15
Enter drückst du weiterhin selbst. Bei COMMIT Nachricht und schließendes
Anführungszeichen ergänzen. Das Terminal sollte vor dem Drücken eine freie
Befehlszeile haben. REPO öffnet die VS-Code-Quellcodeverwaltung.

VS-CODE-TASTENKOMBINATIONEN
Seite 1 nutzt Strg+Alt+F1 bis F7 für Stage, Commit, Fetch, Pull, Push,
Branch und Historie. Seite 2 nutzt Strg+Alt+F13 bis F19 für Terminaltexte.
Die bisherigen Workspace-/Notebook-Belegungen bleiben unverändert.
Einrichten.ps1 ersetzt ausschließlich unseren markierten Data-Science-Block
in %APPDATA%\\Code\\User\\keybindings.json. Andere Einträge bleiben erhalten;
vor einer Änderung wird eine .before-datascience-…bak-Sicherung angelegt.
Eigene Änderungen innerhalb unseres markierten Blocks werden durch v4 ersetzt.
Manuelle Alternative: VSCode-Keybindings.json in „Tastenkombinationen (JSON)“
übernehmen und alte Data-Science-Einträge ersetzen, nicht doppelt hinzufügen.
Bei einem benannten VS-Code-Profil, Insiders oder Portable die tatsächliche
keybindings.json angeben, z. B. in PowerShell:
.\\Einrichten.ps1 -KeybindingsPath 'C:\\Pfad\\keybindings.json'
Mit -SkipProfileImport werden nur die VS-Code-Tasten eingerichtet.

PRÜFUNG
Archiv, Seitenstruktur, Bilder, Navigation, Tastenbelegungen und Übernahme
deiner bestehenden Aktionen wurden geprüft. Der tatsächliche Windows-Import
und das PowerShell-Skript konnten hier nicht unter Windows ausgeführt werden.
Der Export verwendet dieselbe Archivstruktur wie deine funktionierende v2.
'''
(PACK / 'Anleitung.txt').write_text(readme, encoding='utf-8-sig')

def preview(page, page_id, name, title):
    tile, gap, left, top = 144, 14, 28, 83
    image = Image.new('RGB', (1306, 760), '#080e19')
    d = ImageDraw.Draw(image)
    d.text((left, 23), title, font=ImageFont.truetype(icons['BOLD'], 28), fill='#f4f7ff')
    for y in range(4):
        for x in range(8):
            px, py = left + x*(tile+gap), top + y*(tile+gap)
            d.rounded_rectangle((px, py, px+tile, py+tile), radius=12, fill='#101b2b')
            action = page['Controllers'][0]['Actions'].get(f'{x},{y}')
            if not action: continue
            state = action['States'][0]
            relative = state.get('Image')
            if relative:
                path = f'{old_base}/Profiles/{page_id}/{relative}'
                data = assets.get(path, data_map.get(path))
                im = Image.open(BytesIO(data)).convert('RGBA').resize((tile,tile), Image.Resampling.LANCZOS)
                image.paste(im, (px,py), im)
                if state.get('ShowTitle'):
                    label = state.get('Title', '')
                    d.text((px+72,py+123), label, font=ImageFont.truetype(icons['BOLD'], 13), fill='white', anchor='mm')
            elif action['UUID'].startswith('com.elgato.streamdeck.page.'):
                label = 'SEITE 2  →' if action['UUID'].endswith('next') else '←  ZURÜCK'
                d.text((px+72,py+72), label, font=ImageFont.truetype(icons['BOLD'], 18), fill='white', anchor='mm')
            else:
                d.text((px+72,py+72), 'PROGRAMM', font=ImageFont.truetype(icons['BOLD'], 13), fill='#667c99', anchor='mm')
    image.save(PACK / name)
preview(home, home_id, 'Seite-1.png', 'Data Science XL v4 · Seite 1 · Git in VS Code')
preview(terminal, terminal_id, 'Seite-2.png', 'Data Science XL v4 · Seite 2 · Terminalbefehle')

# Assertions test the requested preservation, not just internal consistency.
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None
    assert z.read('package.json') == data_map['package.json']
    assert umbrella['Pages'] == json.loads(data_map[root_manifest])['Pages']
    default = f'{old_base}/Profiles/{umbrella["Pages"]["Default"].upper()}/manifest.json'
    assert z.read(default.replace(old_base,new_base,1)) == data_map[default]
    for position, action in old_home['Controllers'][0]['Actions'].items():
        if position.endswith(',1'): continue
        if position == '7,3': assert ta['0,1'] == action
        else: assert ha[position] == action
    for position, action in old_terminal['Controllers'][0]['Actions'].items():
        assert ta[position] == action
    assert len(ha) == 32 and len(ta) == 11
    ids = [a['ActionID'] for page in [home,terminal] for a in page['Controllers'][0]['Actions'].values()]
    assert len(ids) == len(set(ids))
    for col in range(8):
        expected = deepcopy(old_home['Controllers'][0]['Actions'][f'{col},1'])
        if col < 7: expected['Settings'] = fn(col+13)
        assert ta[f'{col},0'] == expected
    for page, page_id in [(home,home_id),(terminal,terminal_id)]:
        for action in page['Controllers'][0]['Actions'].values():
            for state in action['States']:
                if state.get('Image'):
                    path = f'{new_base}/Profiles/{page_id}/{state["Image"]}'
                    Image.open(BytesIO(z.read(path))).verify()
    for old_path,data in data_map.items():
        if old_path not in replacements:
            assert z.read(old_path.replace(old_base,new_base,1)) == data
source_dir = PACK / 'Quellcode'
source_dir.mkdir(exist_ok=True)
for name in ['update_profile_v4.py', 'build_profile.py', 'repair_profile.py']:
    shutil.copyfile(ROOT / 'work' / name, source_dir / name)
zip_path = OUT / 'DataScience-XL-v4-Paket.zip'
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:
    for file in sorted(PACK.rglob('*')):
        if file.is_file(): z.write(file, str(file.relative_to(OUT)))
print(json.dumps({'profile':str(DEST), 'package':str(zip_path), 'main_actions':len(ha), 'page2_actions':len(ta), 'bindings':len(bindings), 'checks':'passed'}, indent=2))
