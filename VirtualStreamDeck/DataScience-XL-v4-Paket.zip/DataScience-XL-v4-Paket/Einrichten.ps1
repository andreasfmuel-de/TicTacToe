﻿param(
    [string]$KeybindingsPath,
    [switch]$SkipProfileImport
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# Read a JSON-with-comments array without reformatting existing settings.
# Comments and quoted strings may themselves contain brackets or commas.
function Get-ArrayInsertionPoint {
    param([string]$Text)
    $inString = $false
    $escaped = $false
    $inLineComment = $false
    $inBlockComment = $false
    $depth = 0
    $first = -1
    $last = -1
    $beforeClose = ''
    $previous = ''
    $closed = $false

    for ($i = 0; $i -lt $Text.Length; $i++) {
        $c = $Text[$i]
        $next = [char]0
        if ($i + 1 -lt $Text.Length) { $next = $Text[$i + 1] }

        if ($inLineComment) {
            if ($c -eq "`r" -or $c -eq "`n") { $inLineComment = $false }
            continue
        }
        if ($inBlockComment) {
            if ($c -eq '*' -and $next -eq '/') { $inBlockComment = $false; $i++ }
            continue
        }
        if ($inString) {
            if ($escaped) { $escaped = $false; continue }
            if ($c -eq '\') { $escaped = $true; continue }
            if ($c -eq '"') { $inString = $false; $previous = '"' }
            continue
        }
        if ($c -eq '/' -and $next -eq '/') { $inLineComment = $true; $i++; continue }
        if ($c -eq '/' -and $next -eq '*') { $inBlockComment = $true; $i++; continue }
        if ([char]::IsWhiteSpace($c) -or [int]$c -eq 65279) { continue }

        if ($closed) { throw 'Nach dem JSON-Array steht weiterer Inhalt. Es wurde nichts geaendert.' }
        if ($first -eq -1) {
            if ($c -ne '[') { throw 'Die Tastenkombinationen sind kein JSON-Array. Es wurde nichts geaendert.' }
            $first = $i
        }
        if ($c -eq '"') { $inString = $true; $previous = '"'; continue }
        if ($c -eq '[' -or $c -eq '{') { $depth++ }
        if ($c -eq ']' -or $c -eq '}') {
            $depth--
            if ($depth -lt 0) { throw 'Ungueltige JSON-Klammern. Es wurde nichts geaendert.' }
            if ($depth -eq 0) {
                if ($c -ne ']') { throw 'Ungueltiges JSON-Array. Es wurde nichts geaendert.' }
                $last = $i
                $beforeClose = $previous
                $closed = $true
            }
        }
        $previous = [string]$c
    }
    if ($first -eq -1 -or $last -eq -1 -or $inString -or $inBlockComment -or $depth -ne 0) {
        throw 'Die vorhandene Datei ist unvollstaendig. Es wurde nichts geaendert.'
    }
    return [pscustomobject]@{
        Index = $last
        NeedsComma = ($beforeClose -ne '[' -and $beforeClose -ne ',')
    }
}

try {
    $bindingSource = Join-Path $PSScriptRoot 'VSCode-Keybindings.json'
    $profileSource = Join-Path $PSScriptRoot 'DataScience-XL-v4.streamDeckProfile'
    if (-not (Test-Path -LiteralPath $bindingSource -PathType Leaf)) { throw 'VSCode-Keybindings.json fehlt. Bitte das gesamte ZIP entpacken.' }
    if (-not (Test-Path -LiteralPath $profileSource -PathType Leaf)) { throw 'Die Profildatei fehlt. Bitte das gesamte ZIP entpacken.' }

    if (-not $KeybindingsPath) {
        if (-not $env:APPDATA) { throw 'APPDATA fehlt. Dieses Paket ist fuer Windows.' }
        $KeybindingsPath = Join-Path $env:APPDATA 'Code\User\keybindings.json'
        $codeUserPath = Split-Path -Parent $KeybindingsPath
        if (-not (Test-Path -LiteralPath $codeUserPath -PathType Container)) {
            throw 'Der normale VS-Code-Konfigurationsordner fehlt. Bitte VS Code zuerst starten. Fuer Portable/Insiders oder ein benanntes Profil siehe Anleitung.'
        }
    }
    $KeybindingsPath = [IO.Path]::GetFullPath($KeybindingsPath)
    if ([IO.Path]::GetFileName($KeybindingsPath) -ne 'keybindings.json') { throw 'Das Ziel muss keybindings.json heissen.' }
    if (-not (Test-Path -LiteralPath (Split-Path -Parent $KeybindingsPath) -PathType Container)) { throw 'Der Zielordner existiert nicht.' }

    $marker = '// KARSTEN_DATASCIENCE_DECK_V4'
    $text = "[`r`n]`r`n"
    $existed = Test-Path -LiteralPath $KeybindingsPath -PathType Leaf
    if ($existed) { $text = [IO.File]::ReadAllText($KeybindingsPath) }
    $null = Get-ArrayInsertionPoint -Text $text
    $fragment = [IO.File]::ReadAllText($bindingSource).Trim()
    $null = ConvertFrom-Json -InputObject $fragment
    if (-not $fragment.StartsWith('[') -or -not $fragment.EndsWith(']')) { throw 'Das mitgelieferte Tastenformat ist ungueltig.' }
    $fragment = $fragment.Substring(1, $fragment.Length - 2).Trim()
    $block = "    $marker`r`n$fragment`r`n    // ENDE_KARSTEN_DATASCIENCE_DECK_V4"
    $pattern = '(?ms)^[ \t]*// KARSTEN_DATASCIENCE_DECK_V(1|4)\r?\n.*?^[ \t]*// ENDE_KARSTEN_DATASCIENCE_DECK_V\1[^\r\n]*'
    $matches = [regex]::Matches($text, $pattern)
    if ($matches.Count -gt 1) { throw 'Mehrere Data-Science-Bloecke gefunden. Es wurde nichts geaendert.' }
    if ($matches.Count -eq 1) {
        $match = $matches[0]
        $newText = $text.Substring(0, $match.Index) + $block + $text.Substring($match.Index + $match.Length)
    } else {
        if ($text.Contains('KARSTEN_DATASCIENCE_DECK_')) { throw 'Unvollstaendiger Data-Science-Block. Es wurde nichts geaendert.' }
        $point = Get-ArrayInsertionPoint -Text $text
        $separator = ''
        if ($point.NeedsComma) { $separator = ',' }
        $newText = $text.Insert($point.Index, "`r`n$separator`r`n$block`r`n")
    }
    $null = Get-ArrayInsertionPoint -Text $newText
    if ($newText -eq $text) {
        Write-Host 'Die Data-Science-Tasten sind bereits aktuell.' -ForegroundColor Green
    } else {
        if ($existed) {
            $stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
            $backupPath = "$KeybindingsPath.before-datascience-$stamp.bak"
            Copy-Item -LiteralPath $KeybindingsPath -Destination $backupPath
            Write-Host "Sicherung: $backupPath"
        }
        $encoding = New-Object System.Text.UTF8Encoding($false)
        [IO.File]::WriteAllText($KeybindingsPath, $newText, $encoding)
        Write-Host '23 Data-Science-Tastenkombinationen eingerichtet / aktualisiert.' -ForegroundColor Green
        Write-Host "Ziel: $KeybindingsPath"
    }

    if (-not $SkipProfileImport) {
        try {
            $importUri = 'streamdeck://app/openfile/' + [Uri]::EscapeDataString([IO.Path]::GetFullPath($profileSource))
            Start-Process -FilePath $importUri
            Write-Host 'Die Profildatei wurde fuer den Stream-Deck-Import geoeffnet.'
        } catch {
            Write-Host 'Bitte DataScience-XL-v4.streamDeckProfile in der Stream-Deck-App importieren.' -ForegroundColor Yellow
        }
    }
    Write-Host ''
    Write-Host 'Jetzt in Stream Deck das Profil "Data Science XL v4" auswaehlen.'
    Write-Host 'Dann VS Code aktivieren und TERMINAL / JUPYTER testen.'
    Write-Host 'Seite 1: Git direkt in VS Code. Seite 2: Terminaltext, Enter selbst druecken.'
    exit 0
} catch {
    Write-Host ''
    Write-Host "Einrichtung abgebrochen: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
